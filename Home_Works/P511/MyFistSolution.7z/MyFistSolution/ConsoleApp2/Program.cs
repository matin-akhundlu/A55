﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Salam");
            Console.ReadKey();
            Console.WriteLine("Bu bir C# numunesidir.");
            Console.ReadKey();
            Console.WriteLine("Programin sonudur. Eger programi baglamaq isteyirsinizse istenilen duymeni sixin.");
            Console.ReadKey();
        }
    }
}
